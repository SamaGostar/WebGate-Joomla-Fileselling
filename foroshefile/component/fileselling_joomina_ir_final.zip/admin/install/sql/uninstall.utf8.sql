

DROP TABLE `#__joominafs`;

DROP TABLE `#__joominafs_seting`;


<?php
/**
 * CHANGELOG
 *
 * This is the changelog for joominaFS.<br>
 * <b>Please</b> be patient =;)
 *
 * @version    SVN $Id: CHANGELOG.php 466 2011-07-28 01:48:35Z elkuku $
 * @package    joominaFS
 * @subpackage Documentation
 * @author     AmiRezaTehrani {@link http://joomina.ir}
 * @author     Created on 18-Mar-2012
 */

//--No direct access to this changelog...
defined('_JEXEC') || die('=;)');

//--For phpDocumentor documentation we need to construct a function ;)
/**
 * CHANGELOG
 * {@source}
 */
function CHANGELOG()
{
/*
_______________________________________________
_______________________________________________

This is the changelog for joominaFS

Please be patient =;)
_______________________________________________
_______________________________________________

Legend:

 * -> Security Fix
 # -> Bug Fix
 + -> Addition
 ^ -> Change
 - -> Removed
 ! -> Note
______________________________________________

18-Mar-2012 AmiRezaTehrani
 ! Startup

*/
}//--This is the END